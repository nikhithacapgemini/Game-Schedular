package com.cg.gamespringbootdata.dto;

import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;
/**
 * @author nnalamot:Nikhitha
 * **/
 
@Entity
public class Game {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@Column(unique=true)
	private String name;
	private String category;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="game_id")
	private List<Day> days;
	public Game() {
		
	}
	public Game(int id, String name, String category, List<Day> days) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
		this.days = days;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public List<Day> getDays() {
		return days;
	}
	public void setDays(List<Day> days) {
		this.days = days;
	}
	@Override
	public String toString() {
		return "Game [id=" + id + ", name=" + name + ", category=" + category + ", days=" + days + "]";
	}
	
}
