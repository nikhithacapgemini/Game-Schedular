package com.cg.gamespringbootdata.controller;
import org.apache.log4j.Logger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.gamespringbootdata.dto.Day;
import com.cg.gamespringbootdata.dto.Game;
import com.cg.gamespringbootdata.exception.GameException;
import com.cg.gamespringbootdata.service.GameService;
/**
 * 
 * @author nnalamot:Nikhitha
 * @RestController is a convenience annotation that is itself annotated with @Controller and @ResponseBody
 */
@RestController
@RequestMapping("/game")
public class GameController {
	@Autowired
	GameService gameService;
	public static final Logger logger = Logger.getLogger(GameController.class);
	
	//-------------------------------------------------------------------
			/** @Author Nikhitha
			 * Written on25-05-2019
			 * last Modified 27-05-2019
			 * @RequestParam 
			 * @return com.cg.gamespringbootdata.Game
			 * It will add game data and return game object **/
	//--------------------------------------------------------------------
	@RequestMapping(value="/addAll",method=RequestMethod.POST)
	public ResponseEntity<Game> addAll(
										@RequestParam("name") String name,
										@RequestParam("category") String category,
										@RequestParam("did") int did,
										@RequestParam("ddate") @DateTimeFormat(pattern = "yyyy-MM-dd")Date ddate) throws GameException
	{					
		List<Day> days=new ArrayList<Day>();
		Day day =new Day();
		day.setId(did);
		day.setDate(ddate);
		days.add(day);
		Game game=new Game();
		game.setName(name);
		game.setCategory(category);
		game.setDays(days);
		Game ga=gameService.addGame(game);
		if(ga!=null)
			return new ResponseEntity<Game>(ga,HttpStatus.OK);
		return new ResponseEntity(ga,HttpStatus.NOT_FOUND);	
		
	}
					
	//-------------------------------------------------------------------
		/** @Author Nikhitha
		 * Written on25-05-2019
		 * last Modified 27-05-2019
		 * @RequestParam String name
		 * @Exception com.cg.gamespringbootdata.exception
		 * @return game 
		 * It will game data by using game name **/
	//--------------------------------------------------------------------
	@RequestMapping(value="/searchName",method=RequestMethod.GET)
	public ResponseEntity<Game> searchGameName(@RequestParam("name")String name) throws GameException {
		try {
		Game game=gameService.searchByName(name);
		return new ResponseEntity<Game>(game,HttpStatus.OK);
		}
		catch(GameException e) 
		{
			return new ResponseEntity("No Game found with this name "+name,HttpStatus.NOT_FOUND);
		}
		
	}
	//-----------------------------------------------------------------------
		/** @Author Nikhitha
		* Written on25-05-2019
		* last Modified 27-05-2019
		* @RequestParam String name
		* @Exception com.cg.gamespringbootdata.exception
		* @return List<Game> 
		* It will return game data by using game category **/
	//-----------------------------------------------------------------------
	@RequestMapping(value="/searchCategory",method=RequestMethod.GET) 
	public ResponseEntity<List<Game>> searchGameCategory(@RequestParam("category")String category) throws GameException{
		List<Game> myList=null;
		try {
		myList=gameService.searchByCategory(category);
		System.out.println(myList);
			
		}
		catch(GameException e1) {
			return new ResponseEntity("No category found with this name "+category,HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Game>>(myList,HttpStatus.OK);
		
	}
}
