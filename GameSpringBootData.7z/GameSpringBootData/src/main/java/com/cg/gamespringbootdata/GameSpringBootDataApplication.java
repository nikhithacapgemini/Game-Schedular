package com.cg.gamespringbootdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
/**
 * @author nnalamot:Nikhitha
 * Written on 25-05-2019
 * last Modified 27-05-2019
 * The class MyProjectSpringDataApplication is used to declare a main method in which we will 
 * call a static method called run .
 * @SpringBootApplication is a common annotation that wraps up the 3 annotations i.e.,@Configuration,
 * @ComponentScan,@AutoEnableConfiguration
 * SpringApplication.run() method,It creates an appropriate ApplicationContext instance and load beans
 */
@SpringBootApplication
@ComponentScan("com.cg.gamespringbootdata")
public class GameSpringBootDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameSpringBootDataApplication.class, args);
		System.out.println("Game Schedular project started");
	}

}
