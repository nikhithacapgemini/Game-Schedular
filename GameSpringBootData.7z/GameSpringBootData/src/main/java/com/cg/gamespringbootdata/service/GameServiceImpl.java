package com.cg.gamespringbootdata.service;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.gamespringbootdata.controller.GameController;
import com.cg.gamespringbootdata.dao.GameDao;
import com.cg.gamespringbootdata.dto.Day;
import com.cg.gamespringbootdata.dto.Game;
import com.cg.gamespringbootdata.exception.GameException;
@Service
/**
 * @author Nikhitha
 * class used to perform business logic on object and interact with GameDao to perform curd operation
 */
public class GameServiceImpl implements GameService{
	@Autowired
	GameDao gameDao;
	//------------------------------------------------------------
	/** @Author Nikhitha
	 * Written on 25-05-2019
	 * last Modified 27-05-2019
	 * @return com.cg.gamespringbootdata.Game
	 * It will add data and return game 
	 * @throws GameException **/
	//-------------------------------------------------------------
	@Override
	public Game addGame(Game game) throws GameException {
		// TODO Auto-generated method stub
		 Game gOne;
			//gOne=getGame(game.getId());
			gOne=getGame(game.getName());
			if(gOne==null) {
				gameDao.save(game);
				return game;
			}
			else{
				List<Day> dayList=new ArrayList<Day>();
				dayList=gOne.getDays();
				System.out.println(dayList);
				System.out.println(game.getDays());
				dayList.add(game.getDays().get(0));
				gOne.setDays(dayList);
				gameDao.save(gOne);
			}
			if(GameController.logger.isDebugEnabled()){
				GameController.logger.debug("addGameService addGame(Game) is executed!");
			}		
			return game;
	}
	//----------------------------------------------------------------
		/** @Author Nikhitha
		 * Written on25-05-2019
		 * last Modified 27-05-2019
		 * @return com.cg.gamespringbootdata.Game
		 * It will find game data by using game name 
		 * @throws GameException if data not present **/
	//---------------------------------------------------------------

	@Override
	public Game searchByName(String name) throws GameException {
		// TODO Auto-generated method stub
		Game game=gameDao.findByName(name);
		if(GameController.logger.isDebugEnabled()){
			GameController.logger.debug("GameService searchByName(String) is executed!");
		}
		if(game!=null)
			return game;
		else {
			GameController.logger.error(new GameException());
			throw new GameException("name not found");
		}
	}
	//-------------------------------------------------------------
			/** @Author Nikhitha
			 * Written on 25-05-2019
			 * last Modified 27-05-2019
			 * @return List<Game> 
			 * It will find game data by using game category 
			 * @throws GameException if data not found**/
	//--------------------------------------------------------------

	@Override
	public List<Game> searchByCategory(String category) throws GameException {
		// TODO Auto-generated method stub
		List<Game> games=gameDao.findByCategory(category);
		if(GameController.logger.isDebugEnabled()){
			GameController.logger.debug("GameService searchByCategory(String) is executed!");
		}
		if(games.isEmpty()) {
			GameController.logger.error(new GameException());
			throw new GameException("category not found");}
		return games;
		}
	
	

	/*public Game getGame(Integer id) {
	// TODO Auto-generated method stub
		Game game=null;
		game=gameDao.findById(id);
		return game;
	}*/
	public Game getGame(String name) {
	// TODO Auto-generated method stub
			Game game=null;
			game=gameDao.findByName(name);
			return game;
			
	}		
	
}

