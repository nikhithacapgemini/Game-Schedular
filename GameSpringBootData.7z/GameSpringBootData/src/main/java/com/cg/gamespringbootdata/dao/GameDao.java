package com.cg.gamespringbootdata.dao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.gamespringbootdata.dto.Game;
public interface GameDao extends JpaRepository<Game,Integer>{
	
	Game findByName(String name);
	List<Game> findByCategory(String category);
	//Game findById(int id);
}
